#!/usr/bin/env node

console.log("This is a test Claude script");
console.log("Runtime:", process.argv[0]);